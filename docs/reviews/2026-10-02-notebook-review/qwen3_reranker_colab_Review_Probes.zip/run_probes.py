"""Row 73 probes: qwen3-reranker-pipeline tutorials/qwen3_reranker_colab.ipynb @ f13a58e (blob 99efdc6a).

CPU only (CUDA_VISIBLE_DEVICES=-1). Imports the carried modules from the worktree's src/ (the notebook's
module cells are byte-checked against them by the repo's parity test). The corpus is read from a scratch copy
of the pinned Banking77 cache (digest-verified by fetch_corpus). The model probe (P5) uses the locally staged
pinned snapshot, digest-verified by verify_snapshot, on CPU float32 with stand-in subset sizes and lr.

Usage: python run_probes.py <worktree> <corpus_cache_dir> <weights_dir|-> <out_json>
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

os.environ.setdefault("CUDA_VISIBLE_DEVICES", "-1")
WT, CACHE, WEIGHTS, OUT = (Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4]))
sys.path.insert(0, str(WT / "src"))
NB = WT / "tutorials" / "qwen3_reranker_colab.ipynb"
results: dict = {}


def save():
    OUT.write_text(json.dumps(results, indent=2, ensure_ascii=False, default=str), encoding="utf-8")


# ---- P1 static -------------------------------------------------------------------------------------------
nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]
md = ["".join(c["source"]) for c in cells if c["cell_type"] == "markdown"]
code = ["".join(c["source"]) for c in cells if c["cell_type"] == "code"]
all_md = "\n".join(md)
all_code = "\n".join(code)
blob = subprocess.run(["git", "-C", str(WT), "rev-parse", "HEAD:tutorials/qwen3_reranker_colab.ipynb"],
                      capture_output=True, text=True).stdout.strip()
results["P1_static"] = {
    "blob": blob,
    "metadata_dimer": nb["metadata"].get("dimer"),
    "n_cells": len(cells), "n_code": len(code),
    "double_brace_literals_in_markdown": re.findall(r"`?\{\{[^}]*\}\}`?", all_md),
    "restart_guard_present": "Restart the runtime, then rerun from the top" in all_code,
    "pip_install_into_kernel": "'-m', 'pip', 'install'" in all_code,
    "uv_isolated_env": ("uv venv" in all_code) or ("uv pip" in all_code),
    "byod_upload_only_no_location_field": ("files.upload()" in all_code) and not re.search(r"BYOD_PATH|DATA_PATH", all_code),
    "pipe_constructed_only_in_section3": all_code.count("Qwen3RerankerPipeline.from_pretrained(") == 1,
    "hardcoded_claims": {k: (k in all_md) for k in ["+4.5 points", "about 126 MB", "77.9 %", "73.4 %", "a few minutes on CPU"]},
    "guided_layer_markers": {k: (k.lower() in all_md.lower()) for k in [
        "How to use this notebook", "Roadmap", "Glossary", "Predict", "Check your reasoning",
        "What to notice", "Troubleshooting", "Infrastructure", "<details>"]},
    "unconditional_asserts": [l.strip() for l in all_code.splitlines() if l.strip().startswith("assert ")],
    "spec_version_declared": nb["metadata"]["dimer"]["notebook_spec"],
}
save()

# ---- P2 corpus, split and lexical baseline ---------------------------------------------------------------
from qwen3_reranker_pipeline import samples, metrics  # noqa: E402

t0 = time.perf_counter()
corpus = samples.read_corpus(samples.fetch_corpus(cache_dir=CACHE))
splits = samples.build_sample_dataset(corpus, seed=42)
mans = {k: samples.validate_dataset(v) for k, v in splits.items()}
disjoint = samples.check_split_disjoint(splits)
floor = metrics.random_floor([1 + len(r["negatives"]) for r in splits["test"]])
lex = metrics.lexical_baseline(splits["test"])
results["P2_sample"] = {
    "raw_rows": {k: len(v) for k, v in corpus.items()},
    "splits": disjoint,
    "digests": {k: m["digest"][:8] for k, m in mans.items()},
    "random_floor": {k: round(floor[k], 4) for k in ("recall@1", "recall@3", "recall@5", "mrr")},
    "lexical": {k: round(lex[k], 4) for k in ("recall@1", "recall@3", "recall@5", "mrr")} | {"median_rank": lex.get("median_rank")},
    "lexical_below_floor": {k: lex[k] < floor[k] for k in ("recall@1", "recall@3", "recall@5", "mrr")},
    "seconds": round(time.perf_counter() - t0, 2),
}

# lexical: how often is the positive's Jaccard strictly above all hard negatives? (selection effect)
beats = ties = zero = 0
for r in splits["test"]:
    jp = metrics.jaccard(r["query"], r["positive"])
    jh = [metrics.jaccard(r["query"], n) for n in r["negatives"][:3]]
    zero += jp == 0
    beats += jp > max(jh)
    ties += jp == max(jh)
results["P2_sample"]["lexical_selection"] = {"positive_strictly_above_all_hard": beats, "tied_with_best_hard": ties,
                                             "positive_jaccard_zero": zero, "n": len(splits["test"])}

# near-duplicates across splits (beyond the case-insensitive exact check)
def norm(s: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", s.lower()))

def toks(s: str) -> set:
    return set(re.findall(r"[a-z0-9]+", s.lower()))

trainval = [(n, r) for n in ("train", "validation") for r in splits[n]]
exact_norm, near = [], []
for t in splits["test"]:
    nt, tt = norm(t["query"]), toks(t["query"])
    for n, r in trainval:
        if norm(r["query"]) == nt:
            exact_norm.append({"test": t["query"], n: r["query"]})
        else:
            tr = toks(r["query"])
            j = len(tt & tr) / max(len(tt | tr), 1)
            if j >= 0.8:
                near.append({"jaccard": round(j, 3), "test": t["query"], n: r["query"], "same_intent": t["intent"] == r["intent"]})
# also train vs validation (selection leakage)
tv_norm = [(a["query"], b["query"]) for a in splits["validation"] for b in splits["train"] if norm(a["query"]) == norm(b["query"])]
results["P2_sample"]["near_duplicates"] = {
    "test_vs_trainval_normalised_exact": exact_norm,
    "test_vs_trainval_jaccard_ge_0.8": near[:10], "n_near": len(near),
    "val_vs_train_normalised_exact": tv_norm,
}
# pool-level: in the full release, how many test messages have a normalised twin in train?
train_norm = {norm(str(r["text"])) for r in corpus["train"]}
results["P2_sample"]["release_level_test_in_train_normalised"] = sum(norm(str(r["text"])) in train_norm for r in corpus["test"])
save()

# ---- P3 BYOD size boundary (as cell 13 runs it: split_dataset, then validate_dataset per split) ------------
def synth(n: int) -> list[dict]:
    return [{"id": f"r{i}", "query": f"query number {i} about topic {i % 7}", "positive": f"doc {i}",
             "negatives": [f"neg {i} a", f"neg {i} b"]} for i in range(n)]

boundary = {}
for n in list(range(8, 61)):
    try:
        sp = samples.split_dataset(synth(n), seed=42)
        for name, part in sp.items():
            samples.validate_dataset(part)
        boundary[n] = "ok " + str({k: len(v) for k, v in sp.items()})
    except ValueError as exc:
        boundary[n] = "ValueError: " + str(exc)[:90]
first_ok = next((n for n in sorted(boundary) if boundary[n].startswith("ok")), None)
upper = {}
for n in (10_000, 10_008, 12_000, 20_000):
    try:
        sp = samples.split_dataset(synth(n), seed=42)
        for name, part in sp.items():
            samples.validate_dataset(part)
        # Section 6 / 8: pipe.lexical_baseline and pipe.evaluate validate with max_records=MAX_EVAL_RECORDS (2000)
        samples.validate_dataset(sp["test"], min_records=1, max_records=2000)
        upper[n] = "ok " + str({k: len(v) for k, v in sp.items()})
    except ValueError as exc:
        upper[n] = "ValueError: " + str(exc)[:90]
results["P3_byod_bounds"] = {"stated_range": "8..20,000 records (Prerequisites)", "first_n_passing_cell13": first_ok,
                             "samples": {n: boundary[n] for n in (8, 12, 13, 20, 40, 49, 50)}, "upper": upper}
save()

# ---- P4 the TRAIN_CANDIDATES "ceiling" -------------------------------------------------------------------
from qwen3_reranker_pipeline import pipeline as P  # noqa: E402
src = (WT / "src/qwen3_reranker_pipeline/pipeline.py").read_text(encoding="utf-8")
results["P4_train_candidates"] = {
    "MAX_TRAIN_CANDIDATES": P.MAX_TRAIN_CANDIDATES,
    "adapt_accepts_range": re.search(r"not 2 <= train_candidates <= (\d+)", src).group(0),
    "exercise_suggests": "TRAIN_CANDIDATES = 6" in all_md,
}
save()

# ---- P5 rerun state (real pinned weights, CPU float32, stand-in subset sizes) ---------------------------
if WEIGHTS != "-":
    t0 = time.perf_counter()
    pipe = P.Qwen3RerankerPipeline.from_pretrained(device="cpu", weights_dir=WEIGHTS)
    instr = samples.TASK_INSTRUCTION if hasattr(samples, "TASK_INSTRUCTION") else P.DEFAULT_INSTRUCTION
    INSTR = "Given a customer support message, judge whether the document names the banking intent it expresses"
    train8, val8 = splits["train"][:8], splits["validation"][:8]
    probe = splits["test"][0]
    pairs = [(probe["query"], d) for d in metrics.candidate_list(probe)]
    s_frozen = [round(x, 6) for x in pipe.rerank(pairs, instruction=INSTR)["scores"]]
    f0 = pipe.evaluate(val8, instruction=INSTR)
    a1 = pipe.adapt(train8, val8, instruction=INSTR, epochs=1, lr=1e-4, batch_size=4, trainable_layers=2, train_candidates=4)
    s_after1 = [round(x, 6) for x in pipe.rerank(pairs, instruction=INSTR)["scores"]]
    # learner re-runs Section 6 (e.g. the "change INSTRUCTION and re-read the frozen numbers" experiment)
    sec6_rerun = pipe.evaluate(val8, instruction=INSTR)
    # learner re-runs Section 7 with TRAINABLE_LAYERS = 1 (the first optional experiment)
    a2 = pipe.adapt(train8, val8, instruction=INSTR, epochs=1, lr=1e-4, batch_size=4, trainable_layers=1, train_candidates=4)
    s_after2 = [round(x, 6) for x in pipe.rerank(pairs, instruction=INSTR)["scores"]]
    keep = ("recall@1", "mrr")
    results["P5_rerun_state"] = {
        "basis": "direct execution, CPU float32, pinned snapshot digest-verified, stand-in sizes (8 train / 8 val, 1 epoch, lr 1e-4)",
        "frozen_val": {k: round(f0[k], 4) for k in keep} | {"adapted_flag": f0["adapted"]},
        "probe_scores_frozen": s_frozen,
        "probe_scores_after_adapt1": s_after1,
        "section6_rerun_after_adapt": {k: round(sec6_rerun[k], 4) for k in keep} | {"adapted_flag": sec6_rerun["adapted"]},
        "adapt2_epoch0_labelled": a2["history"][0].get("note"),
        "adapt2_epoch0_val": {k: round(a2["history"][0]["val"][k], 4) for k in keep},
        "adapt1_epoch0_val": {k: round(a1["history"][0]["val"][k], 4) for k in keep},
        "adapt1_best_epoch": a1["best_epoch"],
        "probe_scores_after_adapt2": s_after2,
        "epoch0_of_second_run_equals_true_frozen_scores": a2["history"][0]["val"] == a1["history"][0]["val"],
        "frozen_scores_restored_before_second_run": s_after1 == s_frozen,
        "seconds": round(time.perf_counter() - t0, 1),
    }
    save()

# ---- source manifest -------------------------------------------------------------------------------------
manifest = {}
for rel in ["tutorials/qwen3_reranker_colab.ipynb", "tutorials/README.md", "docs/release-verification.md",
            "README.md", "STATUS.md", "tools/build_notebook.py", "tools/notebook_template.py",
            "src/qwen3_reranker_pipeline/pipeline.py", "src/qwen3_reranker_pipeline/samples.py",
            "src/qwen3_reranker_pipeline/metrics.py"]:
    manifest[rel] = hashlib.sha256((WT / rel).read_bytes()).hexdigest()
(OUT.parent / "source_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print("done")
